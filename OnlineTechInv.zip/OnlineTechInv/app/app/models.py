from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import *
from sqlalchemy.orm import relationship

db = SQLAlchemy()


class User(db.Model):
    __tablename__ = 'user'
    id = Column(Integer, primary_key=True)
    username = Column(String(60), nullable=False, unique=True)
    _password = Column('password', String(160), nullable=False)
    diary_entries = relationship('DiaryEntry', backref='user')


class Inventory(db.Model):
    __tablename__ = 'inventory'
    id = Column(Integer, primary_key=True)
    name = Column(String(80), nullable=False)
    price = Column(Integer, nullable=False)
    total_quantity = Column(Integer, nullable=False)

